#!/bin/bash
#Fuction:proc low-level discovery
printf '{\n'
printf '\t"data":[\n'
discovery() {
    port=($(sudo netstat -tnlp|grep "$1"|awk '{print $4}'|awk -F":" '{print $NF}'|sort|uniq))
    last=($(sudo netstat -tnlp|grep  "sshd"|awk '{print $4}'|awk -F":" '{print $NF}'|tail -1))
    for key in ${!port[@]}
    do
        if [[ "${port[${key}]}" -eq $last ]]; then
            if [[ "${key}" -eq "((${#port[@]}-1))" ]];then
                printf '\t {\n'
                echo -e '\t\t "{#TCP_PORT}":' \"${port[${key}]}\" 
                printf '\n \t }\n'
                #echo '"{#TCP_PORT}":' \"${port[${key}]}\" ',' '"{#NAME}":' \"$1\"'}'
            fi
        else
            printf '\t {\n'
            echo -e '\t\t "{#TCP_PORT}":' \"${port[${key}]}\"
            printf '\n \t },\n'
            #echo '"{#TCP_PORT}":'\"${port[${key}]}\" ',' '"{#NAME}":' \"$1\"'},'
        fi
    done
}

services="mysqld httpd zabbix_agentd zabbix_server mongod redis-server sshd"
procname="mysqld|httpd|zabbix_agentd|zabbix_server|mongod|redis-server|sshd"

for svr in $services;do
    discovery $svr
done

printf '\t ]\n'
printf '}\n'

